/*
Student Name: Pasquale Palazzolo
Date: 1/14/2015
Assignment: Week #2:: { Homework } - ANALYZE Buggy Search v1
 */

//This file was created during week one of the class as instructed on FSO but I'm still unsure as to what it is used for.