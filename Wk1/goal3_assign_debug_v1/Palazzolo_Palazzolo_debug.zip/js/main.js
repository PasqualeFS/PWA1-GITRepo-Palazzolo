/*
Student Name: Pasquale Palazzolo
Date: 1/9/2015
Assignment: Week #1 :: { Homework } - ANALYZE Buggy Search v1
 */

//I created this main.js file as instructed in FSO

//Create your JavaScript file "main.js" and store it in the directory "PWA1/Wk1/goal3_debug/js/".
//Using JavaScript comments, place your name, date and assignment at the top of the JavaScript file.

/*
    There were no further instruction on what to do with this main.js file except to put my name, date and assignment at the top.
    All of my comments are shown on various lines in the search.js file because that made sense according to the instructions on FSO
 */

